from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
from database import db  # Updated import: now from database.py
from database import User, Resource, Quiz  # Removed db from here
from forms import LoginForm, RegisterForm, UploadForm, QuizForm
from werkzeug.utils import secure_filename
import os
import json


app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///platform.db'
db.init_app(app)

# Create database tables
with app.app_context():
    db.create_all()

# Ensure uploads folder exists
if not os.path.exists('uploads'):
    os.makedirs('uploads')

@app.route('/')
def home():
    if 'user_id' in session:
        resources = Resource.query.all()
        return render_template('dashboard.html', resources=resources)
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and user.check_password(form.password.data):
            session['user_id'] = user.id
            flash('Login successful!', 'success')
            return redirect(url_for('home'))
        flash('Invalid email or password.', 'error')
    return render_template('login.html', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        if User.query.filter_by(email=form.email.data).first():
            flash('Email already exists.', 'error')
        else:
            user = User(email=form.email.data, role=form.role.data)
            user.set_password(form.password.data)
            db.session.add(user)
            db.session.commit()
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
    return render_template('register.html', form=form)

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    form = UploadForm()
    if form.validate_on_submit():
        file = request.files['file']
        if file:
            filename = secure_filename(file.filename)
            file_path = os.path.join('uploads', filename)
            file.save(file_path)
            new_resource = Resource(
                title=form.title.data,
                description=form.description.data,
                filename=filename,
                subject=form.subject.data,
                uploader_id=session['user_id']
            )
            db.session.add(new_resource)
            db.session.commit()
            flash('Resource uploaded successfully!', 'success')
            return redirect(url_for('home'))
    return render_template('upload.html', form=form)

@app.route('/delete_resource/<int:resource_id>', methods=['POST'])
def delete_resource(resource_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    resource = Resource.query.get_or_404(resource_id)
    if resource.uploader_id != session['user_id']:
        flash('You can only delete your own resources.', 'error')
        return redirect(url_for('home'))
    # Delete associated quizzes first to avoid foreign key constraint
    Quiz.query.filter_by(resource_id=resource_id).delete()
    # Delete the file from uploads folder
    if resource.filename and os.path.exists(os.path.join('uploads', resource.filename)):
        os.remove(os.path.join('uploads', resource.filename))
    # Delete the resource from database
    db.session.delete(resource)
    db.session.commit()
    flash('Resource deleted successfully!', 'success')
    return redirect(url_for('home'))

@app.route('/search')
def search():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    query = request.args.get('q', '')
    resources = Resource.query.filter(Resource.title.contains(query) | Resource.subject.contains(query)).all()
    return render_template('dashboard.html', resources=resources, query=query)

@app.route('/create_quiz/<int:resource_id>', methods=['GET', 'POST'])
def create_quiz(resource_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    form = QuizForm()
    if form.validate_on_submit():
        quiz = Quiz(
            title=form.title.data,
            resource_id=resource_id,
            questions=form.questions.data,
            created_by=session['user_id']
        )
        db.session.add(quiz)
        db.session.commit()
        flash('Quiz created!', 'success')
        return redirect(url_for('home'))
    return render_template('create_quiz.html', form=form, resource_id=resource_id)

@app.route('/take_quiz/<int:quiz_id>', methods=['GET', 'POST'])
def take_quiz(quiz_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    quiz = Quiz.query.get_or_404(quiz_id)
    try:
        questions = json.loads(quiz.questions) if quiz.questions else []
    except json.JSONDecodeError:
        questions = []
    score = 0
    if request.method == 'POST':
        for i, q in enumerate(questions):
            user_answer = request.form.get(f'question_{i}')
            if user_answer == q.get('answer'):
                score += 1
        flash(f'Your score: {score}/{len(questions)}', 'info')
        return redirect(url_for('home'))
    return render_template('take_quiz.html', quiz=quiz, questions=questions, enumerate=enumerate)  # Added enumerate=enumerate

@app.route('/uploads/<filename>')
def download_file(filename):
    return send_from_directory('uploads', filename)

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('Logged out.', 'info')
    return redirect(url_for('login'))

@app.route('/about')
def about():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True)