from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, FileField, TextAreaField, SelectField, SubmitField
from wtforms.validators import DataRequired, Email, Length

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class RegisterForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    role = SelectField('Role', choices=[('student', 'Student'), ('teacher', 'Teacher')], default='student')
    submit = SubmitField('Register')

class UploadForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    description = TextAreaField('Description')
    file = FileField('File', validators=[DataRequired()])
    subject = StringField('Subject', validators=[DataRequired()])
    submit = SubmitField('Upload')

class QuizForm(FlaskForm):
    title = StringField('Quiz Title', validators=[DataRequired()])
    questions = TextAreaField('Questions (JSON format)', validators=[DataRequired()])
    submit = SubmitField('Create Quiz')