import os

SECRET_KEY = 'your_secret_key_here'  # Change this to a random string
SQLALCHEMY_DATABASE_URI = 'sqlite:///platform.db'
SQLALCHEMY_TRACK_MODIFICATIONS = False
UPLOAD_FOLDER = 'uploads'